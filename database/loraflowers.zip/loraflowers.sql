-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 09, 2022 at 01:06 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `loraflowers`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `ID` int(11) NOT NULL,
  `productID` int(11) NOT NULL,
  `userID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`ID`, `productID`, `userID`) VALUES
(4, 1, 1),
(5, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `ID` int(11) NOT NULL,
  `userID` tinytext NOT NULL,
  `feedback` mediumtext NOT NULL,
  `visibility` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`ID`, `userID`, `feedback`, `visibility`) VALUES
(1, '1', 'When a beautiful design is combined with powerful technology, it truly is an artwork. I love how my website operates and looks with this theme. Thank you for the awesome product.', 1),
(2, '2', 'When a beautiful design is combined with powerful technology, it truly is an artwork. I love how my website operates and looks with this theme. Thank you for the awesome product.', 1),
(3, '1', 'When a beautiful design is combined with powerful technology, it truly is an artwork. I love how my website operates and looks with this theme. Thank you for the awesome product.', 0),
(4, '3', 'When a beautiful design is combined with powerful technology, it truly is an artwork. I love how my website operates and looks with this theme. Thank you for the awesome product.', 1),
(5, '4', 'When a beautiful design is combined with powerful technology, it truly is an artwork. I love how my website operates and looks with this theme. Thank you for the awesome product.', 1),
(6, '5', 'When a beautiful design is combined with powerful technology, it truly is an artwork. I love how my website operates and looks with this theme. Thank you for the awesome product.', 1),
(7, '6', 'When a beautiful design is combined with powerful technology, it truly is an artwork. I love how my website operates and looks with this theme. Thank you for the awesome product.', 1),
(8, '4', 'When a beautiful design is combined with powerful technology, it truly is an artwork. I love how my website operates and looks with this theme. Thank you for the awesome product.', 0);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `ID` int(11) NOT NULL,
  `img` tinytext NOT NULL,
  `productName` tinytext NOT NULL,
  `category` tinytext NOT NULL,
  `productPrice` float(6,2) NOT NULL,
  `discountPrice` float(6,2) NOT NULL,
  `memberDiscountPrice` float(6,2) NOT NULL,
  `discount` int(11) NOT NULL DEFAULT 0,
  `itemsAvailable` int(11) NOT NULL,
  `description` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`ID`, `img`, `productName`, `category`, `productPrice`, `discountPrice`, `memberDiscountPrice`, `discount`, `itemsAvailable`, `description`) VALUES
(1, 'product1', 'Taisuco Moth Orchid Plant- Phalaenopsis', 'Orchid', 1850.00, 1720.50, 1480.00, 7, 5, 'Moth orchids or phalaenopsis are spectacular long lasting flowers, they make great gifts and are easy to care for. The plant must be kept in an area with sufficient sunlight and watered sparingly, about once or twice a week or less, the blooms last for up to 6 weeks. Our phalaenopsis plants are sourced from our Belihuloya farm and planted in a simple clay pot.'),
(2, 'product2', 'Sonia Dendrobium Orchid Plant', 'Orchid', 1350.00, 1174.50, 1080.00, 13, 10, 'Dendrobium orchids are a symbol of pure affection and make beautiful sturdy indoor plants. The plant must be kept in an area with plenty of natural sunlight and should be watered once or twice a week. The blooms last approximately 4 weeks and the plant flowers 2 or 3 times a year, with proper care. Our orchids are grown in our own farms located in Madampe and planted in a simple clay pot.'),
(3, 'product3', 'Jupiter Moth Orchid Plant- Phalaenopsis amabilis', 'Orchid', 1950.00, 1540.50, 1560.00, 21, 15, 'Moth orchids or phalaenopsis are spectacular long lasting flowers, they make great gifts and are easy to care for. The plant must be kept in an area with sufficient sunlight and watered sparingly, about once or twice a week or less, the blooms last for up to 6 weeks. Our phalaenopsis plants are sourced from our Belihuloya farm and planted in a simple clay pot.'),
(4, 'product4', 'Golden Dragon Moth Orchid- Phalaenopsis', 'Orchid', 859.00, 661.43, 687.20, 23, 5, 'Moth orchids or phalaenopsis are spectacular long lasting flowers, they make great gifts and are easy to care for. The plant must be kept in an area with sufficient sunlight and watered sparingly, about once or twice a week or less, the blooms last for up to 6 weeks. Our phalaenopsis plants are sourced from our Belihuloya farm and planted in a simple clay pot.'),
(5, 'product5', 'Purple Queen Dendrobium Orchid Plant', 'Orchid', 999.99, 949.99, 799.99, 5, 25, 'Dendrobium orchids are a symbol of pure affection and make beautiful sturdy indoor plants. The plant must be kept in an area with plenty of natural sunlight and should be watered once or twice a week. The blooms last approximately 4 weeks and the plant flowers 2 or 3 times a year, with proper care. Our orchids are grown in our own farms located in Madampe and planted in a simple clay pot.\r\n'),
(6, 'product6', 'Thongchai Uncheng Dendrobium Orchid Plant', 'Orchid', 1999.00, 1759.12, 1599.20, 12, 15, 'Dendrobium orchids are a symbol of pure affection and make beautiful sturdy indoor plants. The plant must be kept in an area with plenty of natural sunlight and should be watered once or twice a week. The blooms last approximately 4 weeks and the plant flowers 2 or 3 times a year, with proper care. Our orchids are grown in our own farms located in Madampe and planted in a simple clay pot.'),
(7, 'product7', 'Thai Airway Blue Dendrobium Orchid Plant', 'Orchid', 1250.00, 1037.50, 1000.00, 17, 30, 'Dendrobium orchids are a symbol of pure affection and make beautiful sturdy indoor plants. The plant must be kept in an area with plenty of natural sunlight and should be watered once or twice a week. The blooms last approximately 4 weeks and the plant flowers 2 or 3 times a year, with proper care. Our orchids are grown in our own farms located in Madampe and planted in a simple clay pot.');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `ID` int(11) NOT NULL,
  `fname` text DEFAULT NULL,
  `lname` text DEFAULT NULL,
  `email` text NOT NULL,
  `password` longtext NOT NULL,
  `profilepic` varchar(255) NOT NULL DEFAULT '1.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID`, `fname`, `lname`, `email`, `password`, `profilepic`) VALUES
(1, 'Adam', 'Christian', 'admchris@ieee.org', '$2y$10$UNVgqJ3AtapUkLPaqz9rrehCI8hUjR2oV21WemzOsWjG11PHnLgJm', '5.jpg'),
(2, 'Romie', 'Rains', 'rrains98@gmail.com', '$2y$10$UNVgqJ3AtapUkLPaqz9rrehCI8hUjR2oV21WemzOsWjG11PHnLgJm', '1.jpg'),
(3, 'John', 'Maradona', 'sach.malshan@gmail.com', '$2y$10$UNVgqJ3AtapUkLPaqz9rrehCI8hUjR2oV21WemzOsWjG11PHnLgJm', '1.jpg'),
(4, 'Chris', 'Moris', 'naweensandeepe1998@gmail.com', '$2y$10$UNVgqJ3AtapUkLPaqz9rrehCI8hUjR2oV21WemzOsWjG11PHnLgJm', '1.jpg'),
(5, 'Anjalina', 'White', 'geethsheheran98@gmail.com', '$2y$10$UNVgqJ3AtapUkLPaqz9rrehCI8hUjR2oV21WemzOsWjG11PHnLgJm', '1.jpg'),
(6, 'Shane', 'Warne', 'heshanmalinga@gmail.com', '$2y$10$UNVgqJ3AtapUkLPaqz9rrehCI8hUjR2oV21WemzOsWjG11PHnLgJm', '1.jpg'),
(9, NULL, NULL, 'jeewanga406@gmail.com', '$2y$10$S30hxTHOBPuNoYmEJWRteOrnbagq5n9AjMEGCvxjqBjrE7K/.RJ2K', '1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `ID` int(11) NOT NULL,
  `productID` int(11) NOT NULL,
  `userID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`ID`, `productID`, `userID`) VALUES
(2, 1, 2),
(3, 5, 2),
(28, 1, 1),
(29, 2, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `email` (`email`) USING HASH;

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
